#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include<algorithm>


using namespace std;

//create data structure to hold course information
struct Course{
    string CourseID;
    string CourseTitle;
    string prereq;
    vector<string> prereqs;
};

//declare functions
vector<Course> loadCourses(vector<Course> courses);
void printCourseInfo(vector<Course> courses);
void printCourses(vector<Course> &courses);
int displayMenu();
void sortList(vector<Course> courses);



int main() {

    int x = 0;
    //vector to hold course objectss
    vector<Course> Courses;
    //loop until user enters 9
    while(x!=9){
        //display menu using functon call
        x = displayMenu();
        switch(x) {
            //load courses from csv file using function
            case 1:
                cout<<"Loading courses"<<endl;
                Courses = loadCourses(Courses);
                break;
                //print all courses
            case 2:
                cout<<"Printing All Courses"<<endl;
                printCourses(Courses);
                break;
                //print a single course's info
            case 3:{
                printCourseInfo(Courses);
                break;
            }
            //exit progrm
            case 9:
                cout<<"Thank you! Good-Bye."<<endl;
                break;
                //error handle
            default:
                cout<<"Incorrect Selection. Please enter a selection from the menu."<<endl;
                x = 0;

        }
    }
    return 0;
}

int displayMenu(){
    cout<<"*************************"<<endl;
    cout<<"*         MENU          *"<<endl;
    cout<<"* 1: Load Courses       *"<<endl;
    cout<<"* 2: Print All Courses  *"<<endl;
    cout<<"* 3: Print Course Info  *"<<endl;
    cout<<"* 9: Exit Program       *"<<endl;
    cout<<"*************************"<<endl;
    //get user choice to return
    int choice;
    cout<<"Selection: ";
    cin>>choice;
    return choice;

};

void printCourses(vector<Course>& courses) {
    //sort(courses.begin(),courses.end());
    cout<<courses.size()<<endl;
    for(int i = 0; i < courses.size();++i){
        if(courses.at(i).prereqs.empty()){
            cout<<courses.at(i).CourseID<<": "<<courses.at(i).CourseTitle<<endl;
        }
        if(courses.at(i).prereqs.size() == 1){
            cout<<courses.at(i).CourseID<<": "<<courses.at(i).CourseTitle;
            cout<<" Pre-reqs: "<<courses.at(i).prereqs.at(0)<<endl;
        }
        if(courses.at(i).prereqs.size() == 2) {
            cout << courses.at(i).CourseID << ": " << courses.at(i).CourseTitle;
            cout <<" Pre-reqs: "<< courses.at(i).prereqs.at(0) << " & " << courses.at(i).prereqs.at(1) << endl;
        }
    }

}

void printCourseInfo(vector<Course> courses) {
    cout<<"Enter a course ID in the format of 'CSCI101'."<<endl;
    string searchCourse;
    //get course to search for
    cin>>searchCourse;

//loop throught vector of course objects
    for (auto & course : courses){
        std::string check = (course.CourseID);
        check = string(check);
        //compare search string to object string
        if(check==searchCourse){
            //if found, return it
            cout<<"Match found: ";
            cout<<course.CourseID<<" "<<course.CourseTitle<<endl;
            //if course has prerequisites, print them
            if(!course.prereqs.empty()) {
                cout << "This course has " << course.prereqs.size() << " prerequisites. They are: ";
                if (course.prereqs.size() == 2) {
                    cout << course.prereqs.at(0) << " and " << course.prereqs.at(1);
                } else {
                    cout << course.prereqs.at(0);
                }
            }
            else{cout<<"Course has no prerequisites"<<endl;}

        }

    }


}
//function to load courses into vector
vector<Course> loadCourses(vector<Course> courses) {
    //open file
    fstream myFile;
    string filename = "Courses.csv";
    myFile.open(filename);
    //check if file open
    if (myFile) {
        cout << "Opened." << endl;
        string temp;
        int counter;
        //set up object variables
        string courseID;
        string courseData;
        string courseTitle;
        string Prereq;
        //loop throughto read lines of file
        while (myFile.good()) {
            //save data to temporary vector
            vector<string> temp;
            getline(myFile, courseData);

            temp.push_back(courseData);
            for(int i = 0; i < temp.size();++i){
                stringstream ss(temp.at(0));
                getline(ss,courseID,',');
                //create course object from data
                Course course;
                course.CourseID = courseID;
                getline(ss,courseTitle,',');
                course.CourseTitle = courseTitle;
                while(getline(ss,Prereq,',')){
                    course.prereqs.push_back(Prereq);
                }
                //add course onbject to vector
                courses.push_back(course);

            }
        }
        //close file
        myFile.close();
        //return courses vector
        return courses;

    }
}


